var searchData=
[
  ['addexpense',['AddExpense',['../class_add_expense.html',1,'AddExpense'],['../class_ui_1_1_add_expense.html',1,'Ui::AddExpense'],['../class_add_expense.html#a1c25187814b2bca33e33a9a80bedfda8',1,'AddExpense::AddExpense()']]],
  ['addincome',['AddIncome',['../class_add_income.html',1,'AddIncome'],['../class_ui_1_1_add_income.html',1,'Ui::AddIncome'],['../class_add_income.html#ab3f5279ae28124a61b2655d4cb2a3cfc',1,'AddIncome::AddIncome()']]]
];
