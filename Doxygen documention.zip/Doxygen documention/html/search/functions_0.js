var searchData=
[
  ['addexpense',['AddExpense',['../class_add_expense.html#a1c25187814b2bca33e33a9a80bedfda8',1,'AddExpense']]],
  ['addincome',['AddIncome',['../class_add_income.html#ab3f5279ae28124a61b2655d4cb2a3cfc',1,'AddIncome']]]
];
