var searchData=
[
  ['viewexpense',['ViewExpense',['../class_ui_1_1_view_expense.html',1,'Ui::ViewExpense'],['../class_view_expense.html',1,'ViewExpense']]],
  ['viewincome',['ViewIncome',['../class_view_income.html',1,'ViewIncome'],['../class_ui_1_1_view_income.html',1,'Ui::ViewIncome']]]
];
