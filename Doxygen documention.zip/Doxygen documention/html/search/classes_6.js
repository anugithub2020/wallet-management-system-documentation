var searchData=
[
  ['settings',['Settings',['../class_settings.html',1,'Settings'],['../class_ui_1_1_settings.html',1,'Ui::Settings']]]
];
