var searchData=
[
  ['getamount',['getAmount',['../class_transaction.html#aac0f3fd1887218035fef56d50ddee740',1,'Transaction']]],
  ['getcategorieslist',['getCategoriesList',['../class_transaction.html#a49e4d33ff01054bde2855dc8cba8e0f7',1,'Transaction']]],
  ['getcategory',['getCategory',['../class_transaction.html#a9001d8e203631c42767defab383cc201',1,'Transaction']]],
  ['getdatabasebpath',['getDatabasebPath',['../classdbconnection.html#a460e09ba977ac3fad55a0190359e22d6',1,'dbconnection']]],
  ['getdate',['getDate',['../class_transaction.html#ac64ef639039bf220025cc8af15bcd36d',1,'Transaction']]],
  ['getdescription',['getDescription',['../class_transaction.html#ac6ae56d957306938e89b2576404d1cfd',1,'Transaction']]],
  ['getid',['getId',['../class_transaction.html#ab55ac6a24f28e692fb13c4b705669cb0',1,'Transaction']]],
  ['getparty',['getParty',['../class_transaction.html#a92abda7803ed97cdca6e0d0e121ff93e',1,'Transaction']]],
  ['gettransaction',['getTransaction',['../class_transaction.html#a991fa82ebc10640404c1fbb7175ebfac',1,'Transaction']]]
];
