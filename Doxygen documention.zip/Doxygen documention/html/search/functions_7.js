var searchData=
[
  ['setamount',['setAmount',['../class_transaction.html#add19a1e84dcd6fe6b8e9dcbc8df0e7a4',1,'Transaction']]],
  ['setcategory',['setCategory',['../class_transaction.html#aba41f85263e3799f65b3a11bb14f5a2b',1,'Transaction']]],
  ['setdate',['setDate',['../class_transaction.html#a2842a87656a93b3f5bbf2e5b3d5f9805',1,'Transaction']]],
  ['setdescription',['setDescription',['../class_transaction.html#ac28f53a06905376b9df6e2e7ec982538',1,'Transaction']]],
  ['setid',['setId',['../class_transaction.html#a4189a1f700bee19f478c429d14d0e37d',1,'Transaction']]],
  ['setparty',['setParty',['../class_transaction.html#a581156899b178e0a8af4fbfa8879d9bb',1,'Transaction']]],
  ['settings',['Settings',['../class_settings.html#ab17afd334db0af5f71c027b8eda8d514',1,'Settings']]],
  ['setupedit',['setupEdit',['../class_add_expense.html#aaa1619af87a468e6fa1e38ea27907378',1,'AddExpense::setupEdit()'],['../class_add_income.html#a3f24c2b65839ee82f89b845bc282d463',1,'AddIncome::setupEdit()']]],
  ['setuptable',['setupTable',['../class_view_expense.html#a5951ce0ba9d8b64af4b085ed5a10fff8',1,'ViewExpense::setupTable()'],['../class_view_income.html#ac5842f0bc2eebb02e8f5606ab6c92b19',1,'ViewIncome::setupTable()']]]
];
