var searchData=
[
  ['inserttransaction',['insertTransaction',['../class_expense.html#a9e5fdc792580b930706194301a65d6b6',1,'Expense::insertTransaction()'],['../class_income.html#aa1871d875c4e0cecbe36d56eaf364735',1,'Income::insertTransaction()'],['../class_transaction.html#a81147640ce170a8fe6e3576c5a8db0da',1,'Transaction::insertTransaction()']]]
];
