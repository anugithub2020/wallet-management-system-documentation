var searchData=
[
  ['viewexpense',['ViewExpense',['../class_ui_1_1_view_expense.html',1,'Ui::ViewExpense'],['../class_view_expense.html',1,'ViewExpense'],['../class_view_expense.html#a02b2ed9f3b7d7cc30ac35ffd9b827e9e',1,'ViewExpense::ViewExpense()']]],
  ['viewincome',['ViewIncome',['../class_view_income.html',1,'ViewIncome'],['../class_ui_1_1_view_income.html',1,'Ui::ViewIncome'],['../class_view_income.html#a7fc72dc9246edfe4babdb8a218e4f231',1,'ViewIncome::ViewIncome()']]],
  ['viewtransaction',['viewTransaction',['../class_transaction.html#a8d3e36cfd8e8c250d4f4b43521ebaebc',1,'Transaction']]]
];
