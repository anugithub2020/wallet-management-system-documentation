var searchData=
[
  ['addexpense',['AddExpense',['../class_add_expense.html',1,'AddExpense'],['../class_ui_1_1_add_expense.html',1,'Ui::AddExpense']]],
  ['addincome',['AddIncome',['../class_add_income.html',1,'AddIncome'],['../class_ui_1_1_add_income.html',1,'Ui::AddIncome']]]
];
