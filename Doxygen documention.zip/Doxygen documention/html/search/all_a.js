var searchData=
[
  ['ui_5faddexpense',['Ui_AddExpense',['../class_ui___add_expense.html',1,'']]],
  ['ui_5faddincome',['Ui_AddIncome',['../class_ui___add_income.html',1,'']]],
  ['ui_5flogin',['Ui_Login',['../class_ui___login.html',1,'']]],
  ['ui_5fmainwindow',['Ui_MainWindow',['../class_ui___main_window.html',1,'']]],
  ['ui_5fsettings',['Ui_Settings',['../class_ui___settings.html',1,'']]],
  ['ui_5fviewexpense',['Ui_ViewExpense',['../class_ui___view_expense.html',1,'']]],
  ['ui_5fviewincome',['Ui_ViewIncome',['../class_ui___view_income.html',1,'']]],
  ['updatetransaction',['updateTransaction',['../class_expense.html#a8bc2ccd30d3a4c9724dbd3566dfce83c',1,'Expense::updateTransaction()'],['../class_income.html#ae9b4179bf224460cbe05a7a5566979dd',1,'Income::updateTransaction()'],['../class_transaction.html#a62474c76644283758890fea3acc52bf8',1,'Transaction::updateTransaction()']]],
  ['user',['User',['../class_user.html',1,'']]]
];
